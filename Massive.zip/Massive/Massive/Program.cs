﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace massivKuksheva
{
    class Program
    {
        static void Main(string[] args)
        {// в консоле выводится текст
            Console.Write("Введите количество элементов массива:\t");
            //вводится целочисленая переменная под именем elementCount
            //присвоением значения от преобразования в целое число
            //строки символов из стандартного входного потока
            int n = int.Parse(Console.ReadLine());
            // вводится целочисленый массив под именем myArray
            // по числу элементов elementsCount
            int[] myArray = new int[n];
            Random rand = new Random();
            int sum = 0;
            int p = 1;
            Console.Write("Введите к:\t");
            int k = int.Parse(Console.ReadLine());
            Console.WriteLine("Вывод массива:");
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = rand.Next(1, 20);
                Console.WriteLine(myArray[i]);
                if (myArray[i] / k == 0)
                {
                    //sum = sum + myArray[i];
                    sum += myArray[i];
                    // sum = myArray.Sum();
                    p = p * myArray[i];
                }
            }
            Console.WriteLine("Вывод суммы элементов массива:{sum}");
            Console.WriteLine("Вывод произведение элементов массива:{p}");
            Console.ReadKey();


        }
    }
}

